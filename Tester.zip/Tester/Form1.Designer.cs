﻿
namespace Tester
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.button2_Next = new System.Windows.Forms.Button();
            this.button3_back = new System.Windows.Forms.Button();
            this.button4_cancel = new System.Windows.Forms.Button();
            this.label2_Quantiny = new System.Windows.Forms.Label();
            this.maskedTextBox2_quantity = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox_phone = new System.Windows.Forms.MaskedTextBox();
            this.label_phone = new System.Windows.Forms.Label();
            this.comboBoxPT = new System.Windows.Forms.ComboBox();
            this.labelPT = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(146, 176);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 45);
            this.button1.TabIndex = 0;
            this.button1.Text = "New";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(415, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Postal Code";
            this.label1.Visible = false;
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Location = new System.Drawing.Point(550, 26);
            this.maskedTextBox1.Mask = ">L0L9?9";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(188, 22);
            this.maskedTextBox1.TabIndex = 3;
            this.maskedTextBox1.Visible = false;
            // 
            // button2_Next
            // 
            this.button2_Next.Location = new System.Drawing.Point(34, 402);
            this.button2_Next.Name = "button2_Next";
            this.button2_Next.Size = new System.Drawing.Size(110, 36);
            this.button2_Next.TabIndex = 4;
            this.button2_Next.Text = "Next/Finish";
            this.button2_Next.UseVisualStyleBackColor = true;
            this.button2_Next.Visible = false;
            this.button2_Next.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3_back
            // 
            this.button3_back.Location = new System.Drawing.Point(343, 402);
            this.button3_back.Name = "button3_back";
            this.button3_back.Size = new System.Drawing.Size(110, 36);
            this.button3_back.TabIndex = 5;
            this.button3_back.Text = "BACK";
            this.button3_back.UseVisualStyleBackColor = true;
            this.button3_back.Visible = false;
            this.button3_back.Click += new System.EventHandler(this.button3_back_Click);
            // 
            // button4_cancel
            // 
            this.button4_cancel.Location = new System.Drawing.Point(650, 402);
            this.button4_cancel.Name = "button4_cancel";
            this.button4_cancel.Size = new System.Drawing.Size(110, 36);
            this.button4_cancel.TabIndex = 6;
            this.button4_cancel.Text = "Cancel";
            this.button4_cancel.UseVisualStyleBackColor = true;
            this.button4_cancel.Visible = false;
            this.button4_cancel.Click += new System.EventHandler(this.button4_cancel_Click);
            // 
            // label2_Quantiny
            // 
            this.label2_Quantiny.AutoSize = true;
            this.label2_Quantiny.Location = new System.Drawing.Point(446, 154);
            this.label2_Quantiny.Name = "label2_Quantiny";
            this.label2_Quantiny.Size = new System.Drawing.Size(53, 17);
            this.label2_Quantiny.TabIndex = 7;
            this.label2_Quantiny.Text = "Quntity";
            this.label2_Quantiny.Visible = false;
            // 
            // maskedTextBox2_quantity
            // 
            this.maskedTextBox2_quantity.Location = new System.Drawing.Point(550, 164);
            this.maskedTextBox2_quantity.Mask = "0999999999999999999";
            this.maskedTextBox2_quantity.Name = "maskedTextBox2_quantity";
            this.maskedTextBox2_quantity.Size = new System.Drawing.Size(188, 22);
            this.maskedTextBox2_quantity.SkipLiterals = false;
            this.maskedTextBox2_quantity.TabIndex = 8;
            this.maskedTextBox2_quantity.Visible = false;
            // 
            // maskedTextBox_phone
            // 
            this.maskedTextBox_phone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.maskedTextBox_phone.Location = new System.Drawing.Point(550, 226);
            this.maskedTextBox_phone.Mask = "0000000000";
            this.maskedTextBox_phone.Name = "maskedTextBox_phone";
            this.maskedTextBox_phone.Size = new System.Drawing.Size(188, 15);
            this.maskedTextBox_phone.SkipLiterals = false;
            this.maskedTextBox_phone.TabIndex = 10;
            this.maskedTextBox_phone.Visible = false;
            // 
            // label_phone
            // 
            this.label_phone.AutoSize = true;
            this.label_phone.Location = new System.Drawing.Point(340, 231);
            this.label_phone.Name = "label_phone";
            this.label_phone.Size = new System.Drawing.Size(160, 17);
            this.label_phone.TabIndex = 9;
            this.label_phone.Text = "Contact Phone(10digits)";
            this.label_phone.Visible = false;
            // 
            // comboBoxPT
            // 
            this.comboBoxPT.FormattingEnabled = true;
            this.comboBoxPT.Location = new System.Drawing.Point(550, 98);
            this.comboBoxPT.Name = "comboBoxPT";
            this.comboBoxPT.Size = new System.Drawing.Size(188, 24);
            this.comboBoxPT.TabIndex = 11;
            this.comboBoxPT.Visible = false;
            // 
            // labelPT
            // 
            this.labelPT.AutoSize = true;
            this.labelPT.Location = new System.Drawing.Point(415, 101);
            this.labelPT.Name = "labelPT";
            this.labelPT.Size = new System.Drawing.Size(88, 17);
            this.labelPT.TabIndex = 12;
            this.labelPT.Text = "Product type";
            this.labelPT.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.labelPT);
            this.Controls.Add(this.comboBoxPT);
            this.Controls.Add(this.maskedTextBox_phone);
            this.Controls.Add(this.label_phone);
            this.Controls.Add(this.maskedTextBox2_quantity);
            this.Controls.Add(this.label2_Quantiny);
            this.Controls.Add(this.button4_cancel);
            this.Controls.Add(this.button3_back);
            this.Controls.Add(this.button2_Next);
            this.Controls.Add(this.maskedTextBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "New order";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.Button button2_Next;
        private System.Windows.Forms.Button button3_back;
        private System.Windows.Forms.Button button4_cancel;
        private System.Windows.Forms.Label label2_Quantiny;
        private System.Windows.Forms.MaskedTextBox maskedTextBox2_quantity;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_phone;
        private System.Windows.Forms.Label label_phone;
        private System.Windows.Forms.ComboBox comboBoxPT;
        private System.Windows.Forms.Label labelPT;
    }
}

