﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;

namespace Tester
{
    public partial class Form1 : Form
    {
        private ApplicationDbContext database;
        public Form1()
        {
            InitializeComponent();
            database = new ApplicationDbContext();
        }
        public int ms = 0;                                                              //menu -  step

        private void button1_Click(object sender, EventArgs e)
        {
            ms = 1;
            this.button1.Visible = false;
            this.button2_Next.Visible = true;
            this.button4_cancel.Visible = true;
            ajax_em();            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBoxPT.DataSource = Enum.GetValues(typeof(Models.ProductTypes));
        }

        private void button2_Click(object sender, EventArgs e)  //Next
        {
            ms++;
            ajax_em();

        }
        private void ajax_em()                                          // clear form & switch step 
        {
            this.label1.Visible = false;
            this.maskedTextBox1.Visible = false;
            this.labelPT.Visible = false;
            this.comboBoxPT.Visible = false;
            this.label2_Quantiny.Visible = false;
            this.maskedTextBox2_quantity.Visible = false;
            this.label_phone.Visible = false;
            this.maskedTextBox_phone.Visible = false;
            switch (ms)
            {
                case 0:                                             // Save order, Main screen
                    {
                        MessageBox.Show("Order canceled");
                        this.button2_Next.Visible = false;
                        this.button4_cancel.Visible = false;
                        this.button3_back.Visible = false;
                        this.button1.Visible = true;
                        this.maskedTextBox_phone.Text = null;
                        this.maskedTextBox2_quantity.Text = null;
                        this.maskedTextBox1.Text = null;

                        break;
                    }


                case 1:                                             //Postal code
                    {
                        this.label1.Visible = true;
                        this.maskedTextBox1.Visible = true;
                        this.button3_back.Visible = false;
                        maskedTextBox1.Focus();

                        break;
                    }
                case 2:                                         // Product type
                    {
                        if (maskedTextBox1.Text.Length < 3)
                        {
                        this.label1.Visible = true;
                        this.maskedTextBox1.Visible = true;
                            maskedTextBox1.Focus();
                            ms--;
                            break;
                        }

                        this.comboBoxPT.Visible=true;
                        this.button3_back.Visible = true;
                        break;
                    }
                case 3:                                             //Quantity
                    {
                        this.label2_Quantiny.Visible = true;
                        this.maskedTextBox2_quantity.Visible = true;
                        maskedTextBox2_quantity.Focus();
                        break;
                    }
                case 4:                                                 //Phone #
                    {
                        this.label_phone.Visible = true;
                        this.maskedTextBox_phone.Visible = true;
                        this.maskedTextBox_phone.Focus();

                        break;
                    }
                case 5:                                                     //Show all
                    {
                        if (maskedTextBox_phone.Text.Length < 10)
                        {
                            this.label_phone.Visible = true;
                            this.maskedTextBox_phone.Visible = true;
                            maskedTextBox_phone.Focus();
                            ms--;
                            break;
                        }

                        var customer = (from cast in database.Contacts
                                            where cast.PhoneNumber == this.maskedTextBox_phone.Text
                                            select cast).ToList<Models.Contact>();
                            if (customer.Count == 0)
                            {
                                var new_customer = new Models.Contact
                                {
                                    PhoneNumber = this.maskedTextBox_phone.Text,
                                    IsBusinessCustomer = false,
                                    isOwner = false
                                };
                                database.Contacts.Add(new_customer);
                                database.SaveChanges();
                                MessageBox.Show("New customer added");
                            }
                            else MessageBox.Show("Customer found");
                        

                        this.label1.Visible = true;
                        this.maskedTextBox1.Visible = true;
                        this.labelPT.Visible = true;
                        this.comboBoxPT.Visible = true;
                        this.label2_Quantiny.Visible = true;
                        this.maskedTextBox2_quantity.Visible = true;
                        this.label_phone.Visible = true;
                        this.maskedTextBox_phone.Visible = true;
                        break;
                    }
                case 6:                                             // Save order, Main screen
                    {
                        MessageBox.Show("Order saved");
                        this.button2_Next.Visible = false;
                        this.button4_cancel.Visible = false;
                        this.button3_back.Visible = false;
                        this.button1.Visible = true;
                        this.maskedTextBox_phone.Text = null;
                        this.maskedTextBox2_quantity.Text = null;
                        this.maskedTextBox1.Text = null;

                        break;
                    }


            }
        }
        private void button3_back_Click(object sender, EventArgs e)
        {
            // ms = ms>1 ? ms-1 : 1 ;
            ms--;
            ajax_em();
        }

        private void button4_cancel_Click(object sender, EventArgs e)
        {
            ms = 0;
            ajax_em();
        }
    }
}
