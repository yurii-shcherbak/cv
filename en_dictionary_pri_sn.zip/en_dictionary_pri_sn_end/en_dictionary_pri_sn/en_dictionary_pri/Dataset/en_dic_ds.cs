﻿namespace en_dictionary_pri.Dataset
{


    partial class en_dic_ds
    {
    }
}

namespace en_dictionary_pri.Dataset.en_dic_dsTableAdapters {
    
    
    public partial class en_word_listTableAdapter {
    }
}
