﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace en_dictionary_pri
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'en_dic_ds.en_word_list' table. You can move, or remove it, as needed.
            this.en_word_listTableAdapter.Fill(this.en_dic_ds.en_word_list);
            Search_type_comboBox1.SelectedIndex = 0;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                panel1.Visible = true;
                panel1.Refresh();

                //==================== Select type of search===============
 //=   Search_type_comboBox1.SelectedIndex =0
 //Start with                                =1
 //Ends with                                 =2 
 //Any where                                 =3
                switch (Search_type_comboBox1.SelectedIndex)
                {
                    case  0:
                        this.en_word_listTableAdapter.FillBy_word(this.en_dic_ds.en_word_list, search_textBox1.Text);
                        break;
                    case 1:
                        this.en_word_listTableAdapter.FillBy_like_ssword(this.en_dic_ds.en_word_list, search_textBox1.Text+"%");
                        break;
                    case 2:
                        this.en_word_listTableAdapter.FillBy_like_ssword(this.en_dic_ds.en_word_list, "%"+search_textBox1.Text);
                        break;
                    case 3:
                        this.en_word_listTableAdapter.FillBy_like_ssword(this.en_dic_ds.en_word_list, "%"+search_textBox1.Text+"%");
                        break;
                    default: MessageBox.Show("Please select type of search.");
                        break;
                }
                //this.en_word_listTableAdapter.FillBy_word(this.en_dic_ds.en_word_list, search_textBox1.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:" + ex.Message);
            }
            panel1.Visible = false;
        }
    }
}
